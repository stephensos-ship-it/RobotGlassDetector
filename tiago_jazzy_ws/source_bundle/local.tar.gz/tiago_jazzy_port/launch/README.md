Launch orchestration belongs here. Runtime verification executables are installed
under `lib/tiago_jazzy_port`.
