"""Static acceptance checks that prevent Classic regressions and skipped packages."""

import os
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

from ament_index_python.packages import get_package_share_directory
import pytest
import yaml

FORBIDDEN_DEPENDENCIES = {
    'gazebo_ros',
    'gazebo_ros_pkgs',
    'gazebo_ros2_control',
    'gazebo_dev',
    'gazebo_plugins',
    'gazebo_msgs',
}


def test_navigation_limits_fit_simulated_base():
    navigation = Path(get_package_share_directory('tiago_2dnav'))
    controllers = Path(get_package_share_directory('pmb2_controller_configuration'))
    settings = yaml.safe_load(
        (navigation / 'params/tiago_pmb2_nav_public_sim.yaml').read_text()
    )['controller_server']['ros__parameters']
    planner = settings['DWB']
    base = yaml.safe_load(
        (controllers / 'config/mobile_base_controller.yaml').read_text()
    )['/**/mobile_base_controller']['ros__parameters']
    # A planner predicting accelerations/turn rates the hardware clips can
    # repeatedly stop or recover instead of following an obstacle detour.
    assert planner['max_vel_x'] <= base['linear']['x']['max_velocity']
    assert planner['acc_lim_x'] <= base['linear']['x']['max_acceleration']
    assert planner['max_vel_theta'] <= base['angular']['z']['max_velocity']
    assert planner['acc_lim_theta'] <= base['angular']['z']['max_acceleration']
    tracker = settings['FollowPath']
    assert tracker['desired_linear_vel'] <= base['linear']['x']['max_velocity']
    assert tracker['rotate_to_heading_angular_vel'] <= base['angular']['z']['max_velocity']
    assert tracker['max_angular_accel'] <= base['angular']['z']['max_acceleration']


def source_root():
    value = os.environ.get('TIAGO_JAZZY_SOURCE_ROOT')
    if value:
        return Path(value)
    return Path(__file__).resolve().parents[2]


def test_no_colcon_ignore_markers():
    assert list(source_root().rglob('COLCON_IGNORE')) == []


def test_no_classic_manifest_dependencies():
    violations = []
    for manifest in source_root().rglob('package.xml'):
        root = ET.parse(manifest).getroot()
        for element in root:
            if (
                element.tag.endswith('depend')
                and (element.text or '').strip() in FORBIDDEN_DEPENDENCIES
            ):
                violations.append(f'{manifest}: {element.text.strip()}')
    assert violations == []


CONFIGURATIONS = [
    ('pmb2', 'tiago-arm', 'pal-gripper', 'schunk-ft', 'wrist-2017', 'orbbec-astra', 'sick-571'),
    ('pmb2', 'no-arm', 'no-end-effector', 'no-ft-sensor', 'wrist-2017', 'no-camera', 'no-laser'),
    (
        'omni_base',
        'tiago-arm',
        'pal-gripper',
        'schunk-ft',
        'wrist-2010',
        'orbbec-astra-pro',
        'sick-561',
    ),
    ('pmb2', 'tiago-arm', 'pal-hey5', 'no-ft-sensor', 'wrist-2017', 'asus-xtion', 'hokuyo'),
    ('pmb2', 'tiago-arm', 'robotiq-2f-85', 'schunk-ft', 'wrist-2017', 'orbbec-astra', 'sick-551'),
    ('pmb2', 'tiago-arm', 'robotiq-2f-140', 'schunk-ft', 'wrist-2017', 'orbbec-astra', 'sick-571'),
    (
        'pmb2',
        'tiago-arm',
        'no-end-effector',
        'no-ft-sensor',
        'wrist-2010',
        'no-camera',
        'sick-571',
    ),
]


@pytest.mark.parametrize('base,arm,ee,ft,wrist,camera,laser', CONFIGURATIONS)
def test_harmonic_xacro_matrix(base, arm, ee, ft, wrist, camera, laser):
    xacro = Path(get_package_share_directory('tiago_description')) / 'robots' / 'tiago.urdf.xacro'
    command = [
        'xacro',
        str(xacro),
        'use_sim_time:=true',
        'is_public_sim:=true',
        f'base_type:={base}',
        f'arm_type:={arm}',
        f'end_effector:={ee}',
        f'ft_sensor:={ft}',
        f'wrist_model:={wrist}',
        f'camera_model:={camera}',
        f'laser_model:={laser}',
    ]
    result = subprocess.run(command, check=True, capture_output=True, text=True)
    assert '<robot' in result.stdout
    robot = ET.fromstring(result.stdout)
    plugins = [
        element.attrib.get('filename', element.text or '') for element in robot.iter('plugin')
    ]
    assert not any('libgazebo_' in plugin or 'gazebo_ros2_control' in plugin for plugin in plugins)
    assert 'gz_ros2_control' in result.stdout
