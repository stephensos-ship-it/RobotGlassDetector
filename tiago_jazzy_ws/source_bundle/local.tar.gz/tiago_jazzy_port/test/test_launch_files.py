"""Construct every maintained Python launch entry point using installed Jazzy APIs."""

from pathlib import Path

from launch import LaunchDescription
from launch.launch_description_sources import get_launch_description_from_python_launch_file
import pytest

SOURCE = Path(__file__).resolve().parents[2]
FILES = sorted(
    path
    for path in SOURCE.rglob('*.launch.py')
    if 'launch' in path.parts and not {'moveit2', 'ros_gz'} & set(path.parts)
)


@pytest.mark.parametrize('path', FILES, ids=lambda path: str(path.relative_to(SOURCE)))
def test_construct_launch_description(path):
    description = get_launch_description_from_python_launch_file(str(path))
    assert isinstance(description, LaunchDescription)
