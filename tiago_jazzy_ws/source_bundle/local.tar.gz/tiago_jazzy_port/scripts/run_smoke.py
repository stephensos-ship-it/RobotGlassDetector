#!/usr/bin/env python3
"""Launch, verify, and shut down a headless TIAGo simulation in an isolated domain."""

import argparse
import fcntl
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import tempfile
import time

from ament_index_python.packages import get_package_share_directory


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--world', default='empty')
    parser.add_argument('--moveit', action='store_true')
    parser.add_argument('--navigation', action='store_true')
    parser.add_argument('--slam', action='store_true')
    parser.add_argument('--no-arm', action='store_true')
    parser.add_argument('--base', default='pmb2', choices=['pmb2', 'omni_base'])
    parser.add_argument('--end-effector', default='pal-gripper')
    parser.add_argument('--camera', default='orbbec-astra')
    parser.add_argument('--laser', default='sick-571')
    parser.add_argument('--ft-sensor', default='schunk-ft')
    parser.add_argument('--wrist', default='wrist-2017')
    parser.add_argument('--arm-motor', default='parker')
    parser.add_argument('--screen', action='store_true')
    parser.add_argument('--calibration', action='store_true')
    parser.add_argument('--tuck-arm', action='store_true')
    parser.add_argument('--snapshot', action='store_true')
    parser.add_argument('--multi', action='store_true')
    parser.add_argument('--gripper-only', action='store_true')
    parser.add_argument('--obstacle-check', action='store_true')
    parser.add_argument('--duration', type=float, default=5.0)
    parser.add_argument('--log-dir', default='log/smoke')
    parser.add_argument('--domain', type=int, default=71)
    args = parser.parse_args()
    if args.obstacle_check:
        args.navigation = True
        args.world = str(
            Path(get_package_share_directory('tiago_jazzy_port')) / 'test_data' / 'navigation.sdf'
        )
    # Jazzy's spawner serializes all controller operations with a process-wide
    # ROS_HOME file lock, even across DDS domains. Serialize acceptance runs so
    # one failed launch cannot starve another run's controller initialization.
    smoke_lock = open(Path(tempfile.gettempdir()) / 'tiago-jazzy-smoke.lock', 'w')
    fcntl.flock(smoke_lock, fcntl.LOCK_EX)
    log_dir = Path(args.log_dir).resolve()
    log_dir.mkdir(parents=True, exist_ok=True)
    environment = os.environ.copy()
    environment['ROS_DOMAIN_ID'] = str(args.domain)
    environment['GZ_PARTITION'] = f'tiago_smoke_{os.getpid()}'
    environment.setdefault('QT_QPA_PLATFORM', 'offscreen')
    environment.setdefault('LIBGL_ALWAYS_SOFTWARE', '1')
    command = [
        'ros2',
        'launch',
        'tiago_gazebo',
        'tiago_gazebo.launch.py',
        'is_public_sim:=True',
        'gzclient:=False',
        f'world_name:={args.world}',
        f'moveit:={args.moveit}',
        f'navigation:={args.navigation or args.slam}',
        f'slam:={args.slam}',
        f'tuck_arm:={args.tuck_arm}',
        'rviz:=False',
        f'base_type:={args.base}',
        f'end_effector:={args.end_effector}',
        f'camera_model:={args.camera}',
        f'laser_model:={args.laser}',
        f'ft_sensor:={args.ft_sensor}',
        f'wrist_model:={args.wrist}',
        f'arm_motor_model:={args.arm_motor}',
        f'has_screen:={args.screen}',
        f'calibration_tool:={args.calibration}',
    ]
    if args.no_arm:
        command.append('arm_type:=no-arm')
    if args.obstacle_check:
        command.append('map:=' + str(Path(args.world).with_suffix('.yaml')))
    if args.multi:
        command = [
            'ros2',
            'launch',
            'tiago_multi',
            'multitiago_gazebo.launch.py',
            'gzclient:=False',
            f'world_name:={args.world}',
            f'moveit:={args.moveit}',
            f'navigation:={args.navigation or args.slam}',
            f'slam:={args.slam}',
        ]
    verify = [
        sys.executable,
        str(Path(__file__).with_name('verify_runtime.py')),
        '--end-effector',
        args.end_effector,
        '--base',
        args.base,
    ]
    if args.camera == 'no-camera':
        verify.append('--no-camera')
    if args.laser == 'no-laser':
        verify.append('--no-laser')
    if args.ft_sensor == 'no-ft-sensor':
        verify.append('--no-ft-sensor')
    if args.moveit:
        verify.append('--moveit')
    if args.navigation or args.slam:
        verify.append('--navigation')
    if args.obstacle_check:
        verify.append('--obstacle-check')
    if args.slam:
        verify.append('--slam')
    if args.no_arm:
        verify.append('--no-arm')
    if args.gripper_only:
        command = [
            'ros2',
            'launch',
            'pal_gripper_gazebo',
            'gripper_gazebo.launch.py',
            'gzclient:=False',
        ]
        verify.append('--gripper-only')
    verification_commands = [verify]
    if args.multi:
        verification_commands = [verify + ['--namespace', name] for name in ['tiago1', 'tiago2']]
    status = 1
    with (log_dir / 'launch.log').open('w') as launch_log:
        simulator = subprocess.Popen(
            command,
            env=environment,
            stdout=launch_log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        try:
            if args.tuck_arm:
                deadline = time.monotonic() + 180
                while 'Arm tucked' not in (log_dir / 'launch.log').read_text():
                    if simulator.poll() is not None or time.monotonic() >= deadline:
                        raise subprocess.TimeoutExpired(command, 180)
                    time.sleep(0.2)
            with (log_dir / 'verification.log').open('w') as verify_log:
                status = 0
                for verification in verification_commands:
                    result = subprocess.run(
                        verification,
                        env=environment,
                        stdout=verify_log,
                        stderr=subprocess.STDOUT,
                        timeout=360,
                    )
                    if result.returncode:
                        status = result.returncode
                        break
            if status == 0 and args.snapshot:
                subprocess.run(
                    [
                        sys.executable,
                        str(Path(__file__).with_name('snapshot_interfaces.py')),
                        '--duration',
                        '20',
                        '--output',
                        str(log_dir / 'interfaces.json'),
                    ],
                    env=environment,
                    check=True,
                    timeout=60,
                )
            deadline = time.monotonic() + args.duration
            while status == 0 and time.monotonic() < deadline:
                if simulator.poll() is not None:
                    status = 1
                    break
                time.sleep(0.2)
        except (subprocess.SubprocessError, KeyboardInterrupt):
            status = 1
        finally:
            if simulator.poll() is None:
                # Signal launch first; launch handles orderly shutdown of its children.
                simulator.send_signal(signal.SIGINT)
            try:
                simulator.wait(timeout=30)
            except subprocess.TimeoutExpired:
                print('FAIL: launch did not shut down within 30 seconds', file=sys.stderr)
                os.killpg(simulator.pid, signal.SIGKILL)
                simulator.wait()
                status = 1
    if (log_dir / 'verification.log').exists():
        print((log_dir / 'verification.log').read_text())
    launch_output = re.sub(r'\x1b\[[0-9;]*m', '', (log_dir / 'launch.log').read_text())
    fatal_patterns = [
        'process has died',
        'failed to terminate',
        'Segmentation fault',
        'Traceback (most recent call last)',
        '[Err]',
        '[ERROR]',
        '[FATAL]',
        'corrupted double-linked list',
        'double free or corruption',
        'Caught exception in launch',
    ]
    failures = [
        line
        for line in launch_output.splitlines()
        if any(pattern in line for pattern in fatal_patterns)
    ]
    if failures:
        print('\n'.join(failures), file=sys.stderr)
        status = 1
    if args.multi:
        # gz_ros2_control discovers sensors across the whole world. Verify the
        # actual subscriptions, since two controllers can otherwise report
        # active while both are reading the other robot's sensor.
        bindings = re.findall(
            r'\[(tiago[12])\.gz_ros_control\]: (IMU|ForceTorque) (\S+) '
            r'has a topic name: (\S+)',
            launch_output,
        )
        expected = {
            (robot, kind, f'{robot}__{sensor}', topic)
            for robot in ('tiago1', 'tiago2')
            for kind, sensor, topic in (
                ('IMU', 'base_imu_sensor', f'{robot}/base_imu'),
                (
                    'ForceTorque',
                    'wrist_ft_sensor',
                    f'world/{args.world}/model/{robot}/joint/wrist_ft_joint/'
                    f'sensor/{robot}__wrist_ft_sensor/forcetorque',
                ),
            )
        }
        if set(bindings) != expected or len(bindings) != len(expected):
            print(f'FAIL: cross-robot or missing sensor bindings: {bindings}', file=sys.stderr)
            status = 1
    print(f'Logs: {log_dir}')
    return status


if __name__ == '__main__':
    raise SystemExit(main())
