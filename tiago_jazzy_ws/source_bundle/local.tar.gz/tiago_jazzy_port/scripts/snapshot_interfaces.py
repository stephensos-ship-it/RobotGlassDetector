#!/usr/bin/env python3
"""Record a ROS simulation's graph, TF frames, sensor headers and observed rates."""

import argparse
import json
import os
from pathlib import Path
import time

import rclpy
from rclpy.action import get_action_names_and_types
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from rosidl_runtime_py.utilities import get_message
from tf2_ros import Buffer
from tf2_ros import TransformListener
import yaml


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--duration', type=float, default=15.0)
    args = parser.parse_args()
    rclpy.init()
    node = Node('tiago_interface_snapshot')
    buffer = Buffer()
    listener = TransformListener(buffer, node)
    records = {}
    subscriptions = {}
    deadline = time.monotonic() + args.duration
    while time.monotonic() < deadline:
        for topic, types in node.get_topic_names_and_types():
            if topic in subscriptions or len(types) != 1:
                continue
            if not types[0].startswith(
                ('sensor_msgs/', 'nav_msgs/', 'geometry_msgs/', 'rosgraph_msgs/')
            ):
                continue

            def receiver(name):
                # A default second argument is interpreted as a MessageInfo
                # callback by Humble rclpy. Use an actual one-argument closure.
                def receive(message):
                    now = time.monotonic()
                    record = records.setdefault(name, {'count': 0, 'first': now})
                    record.update(count=record['count'] + 1, last=now)
                    if hasattr(message, 'header'):
                        record['frame_id'] = message.header.frame_id
                    stamp = getattr(
                        message, 'clock', getattr(getattr(message, 'header', None), 'stamp', None)
                    )
                    if stamp is not None:
                        simulation_time = stamp.sec + stamp.nanosec / 1e9
                        record.setdefault('first_simulation_time', simulation_time)
                        record['last_simulation_time'] = simulation_time

                return receive

            subscriptions[topic] = node.create_subscription(
                get_message(types[0]), topic, receiver(topic), qos_profile_sensor_data
            )
        rclpy.spin_once(node, timeout_sec=0.1)
    for record in records.values():
        elapsed = record['last'] - record['first']
        record['wall_hz'] = (record['count'] - 1) / elapsed if elapsed > 0 else 0
        simulation_elapsed = record.get('last_simulation_time', 0) - record.get(
            'first_simulation_time', 0
        )
        record['simulation_hz'] = (
            (record['count'] - 1) / simulation_elapsed if simulation_elapsed > 0 else None
        )
        del record['first'], record['last']
    report = {
        'ros_distro': os.environ.get('ROS_DISTRO'),
        'topics': dict(node.get_topic_names_and_types()),
        'services': dict(node.get_service_names_and_types()),
        'actions': dict(get_action_names_and_types(node)),
        'tf': yaml.safe_load(buffer.all_frames_as_yaml()),
        'observations': records,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    del listener
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
