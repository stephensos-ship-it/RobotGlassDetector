#!/usr/bin/env python3
"""Black-box runtime verification for the TIAGo Jazzy / Harmonic simulation."""

import argparse
import json
import math
import subprocess
import sys
import time

from control_msgs.action import FollowJointTrajectory
from controller_manager_msgs.srv import ListControllers
from geometry_msgs.msg import Twist
from geometry_msgs.msg import WrenchStamped
from lifecycle_msgs.srv import GetState
from moveit_msgs.action import MoveGroup
from moveit_msgs.msg import Constraints
from moveit_msgs.msg import JointConstraint
from moveit_msgs.msg import MoveItErrorCodes
from nav2_msgs.action import NavigateToPose
from nav_msgs.msg import OccupancyGrid
from nav_msgs.msg import Odometry
from play_motion2_msgs.action import PlayMotion2Raw
from play_motion2_msgs.srv import ListMotions
import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.qos import qos_profile_sensor_data
from rosgraph_msgs.msg import Clock
from sensor_msgs.msg import CameraInfo
from sensor_msgs.msg import Image
from sensor_msgs.msg import Imu
from sensor_msgs.msg import JointState
from sensor_msgs.msg import LaserScan
from sensor_msgs.msg import PointCloud2
from sensor_msgs.msg import Range
from tf2_ros import Buffer
from tf2_ros import TransformException
from tf2_ros import TransformListener
from trajectory_msgs.msg import JointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint


class VerificationError(RuntimeError):
    """Raised when an acceptance check fails."""


class RuntimeVerifier(Node):
    """Observe and exercise public simulation interfaces."""

    def __init__(self, args):
        super().__init__('tiago_jazzy_runtime_verifier')
        self.args = args
        self.set_parameters([Parameter('use_sim_time', value=True)])
        self.messages = {}
        self.joints = {}
        self.odom = None
        self.obstacle_track = None
        self.map = None
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        self.cmd_vel = self.create_publisher(Twist, 'cmd_vel', 10)
        self._subscribe('joint_states', JointState, self._joint_state)
        if args.laser:
            self._subscribe('scan_raw', LaserScan)
        if args.camera:
            self._subscribe('head_front_camera/image', Image)
            self._subscribe('head_front_camera/depth_image', Image)
            self._subscribe('head_front_camera/camera_info', CameraInfo)
            self._subscribe('head_front_camera/points', PointCloud2)
        if args.base == 'pmb2':
            self._subscribe('sonar_base', Range)
        if args.ft_sensor and not args.no_arm:
            self._subscribe('ft_sensor_controller/wrench', WrenchStamped)
        self._subscribe('ground_truth_odom', Odometry)
        self._subscribe('imu_sensor_broadcaster/imu', Imu)
        self._subscribe('/clock', Clock)
        self.create_subscription(Odometry, 'mobile_base_controller/odom', self._odom, 10)
        if args.slam:
            self.create_subscription(OccupancyGrid, 'map', self._map, 10)

    def _subscribe(self, topic, msg_type, callback=None):
        if callback is None:

            def callback(msg, name=topic):
                return self.messages.__setitem__(name, msg)

        self.create_subscription(msg_type, topic, callback, qos_profile_sensor_data)

    def _joint_state(self, msg):
        self.messages['joint_states'] = msg
        self.joints.update(dict(zip(msg.name, msg.position)))

    def _odom(self, msg):
        self.messages['mobile_base_controller/odom'] = msg
        self.odom = msg
        if self.obstacle_track is not None:
            self.obstacle_track.append((msg.pose.pose.position.x, msg.pose.pose.position.y))

    def _map(self, msg):
        self.messages['map'] = msg
        self.map = msg

    def spin_until(self, predicate, timeout, description):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline and rclpy.ok():
            rclpy.spin_once(self, timeout_sec=0.1)
            if predicate():
                return
        raise VerificationError(f'timed out waiting for {description}')

    def verify_topics(self):
        expected = {
            'joint_states',
            'imu_sensor_broadcaster/imu',
            'mobile_base_controller/odom',
            'ground_truth_odom',
        }
        if self.args.camera:
            expected.update(
                [
                    'head_front_camera/image',
                    'head_front_camera/depth_image',
                    'head_front_camera/camera_info',
                    'head_front_camera/points',
                ]
            )
        if self.args.laser:
            expected.add('scan_raw')
        if self.args.base == 'pmb2':
            expected.add('sonar_base')
        if self.args.ft_sensor and not self.args.no_arm:
            expected.add('ft_sensor_controller/wrench')
        self.spin_until(
            lambda: expected <= self.messages.keys(),
            90.0,
            'joint, odometry, IMU, lidar, and RGB-D messages',
        )
        self.spin_until(lambda: '/clock' in self.messages, 10.0, 'simulation clock')
        initial_clock = self.messages['/clock'].clock
        initial_ns = initial_clock.sec * 1_000_000_000 + initial_clock.nanosec
        self.spin_until(
            lambda: self.get_clock().now().nanoseconds > initial_ns + 100_000_000,
            10.0,
            'advancing simulation clock',
        )
        if self.args.laser:
            scan = self.messages['scan_raw']
            if not scan.ranges or scan.angle_increment <= 0.0:
                raise VerificationError('laser scan payload is invalid')
        if self.args.camera:
            image = self.messages['head_front_camera/image']
            depth = self.messages['head_front_camera/depth_image']
            info = self.messages['head_front_camera/camera_info']
            if not image.data or not depth.data or info.width == 0 or info.height == 0:
                raise VerificationError('RGB-D camera payload is invalid')
            cloud = self.messages['head_front_camera/points']
            if not cloud.data or cloud.point_step == 0 or cloud.width * cloud.height == 0:
                raise VerificationError('RGB-D point cloud payload is invalid')
        if self.args.ft_sensor and not self.args.no_arm:

            def physical_wrench():
                force = self.messages['ft_sensor_controller/wrench'].wrench.force
                values = (force.x, force.y, force.z)
                return all(math.isfinite(value) for value in values) and math.hypot(*values) > 0.01

            self.spin_until(physical_wrench, 15.0, 'physical force-torque measurements')

    def verify_tf(self):
        def available():
            try:
                self.tf_buffer.lookup_transform('odom', 'base_footprint', rclpy.time.Time())
                self.tf_buffer.lookup_transform('base_footprint', 'head_2_link', rclpy.time.Time())
                return True
            except TransformException:
                return False

        self.spin_until(available, 30.0, 'odom/base/head TF chain')
        for topic, message in self.messages.items():
            if topic.startswith('head_front_camera') or topic in ['scan_raw', 'sonar_base']:
                frame = message.header.frame_id
                self.spin_until(
                    lambda: self.tf_buffer.can_transform(
                        'base_footprint', frame, rclpy.time.Time()
                    ),
                    15.0,
                    f'{topic} sensor frame {frame}',
                )

    def verify_controllers(self):
        client = self.create_client(ListControllers, 'controller_manager/list_controllers')
        if not client.wait_for_service(timeout_sec=30.0):
            raise VerificationError('controller manager service is unavailable')
        required = {
            'joint_state_broadcaster',
            'mobile_base_controller',
            'head_controller',
            'torso_controller',
            'imu_sensor_broadcaster',
        }
        if self.args.gripper_only:
            required = {'joint_state_broadcaster', 'gripper_controller'}
        elif not self.args.no_arm:
            required.add('arm_controller')
            if self.args.ft_sensor:
                required.add('ft_sensor_controller')
            if self.args.end_effector not in ['no-end-effector', 'custom']:
                required.add(
                    'hand_controller'
                    if self.args.end_effector == 'pal-hey5'
                    else 'gripper_controller'
                )
        missing = required
        deadline = time.monotonic() + 60.0
        while missing and time.monotonic() < deadline:
            future = client.call_async(ListControllers.Request())
            rclpy.spin_until_future_complete(self, future, timeout_sec=10.0)
            if future.result() is None:
                raise VerificationError('controller manager did not answer')
            active = {
                controller.name
                for controller in future.result().controller
                if controller.state == 'active'
            }
            missing = required - active
            rclpy.spin_once(self, timeout_sec=0.25)
        if missing:
            raise VerificationError(f'inactive controllers: {sorted(missing)}')

    def verify_base_motion(self):
        self.spin_until(lambda: self.odom is not None, 20.0, 'initial odometry')
        start = self.odom.pose.pose.position
        start_xy = (start.x, start.y)
        command = Twist()
        command.linear.x = 0.15
        start_time = self.get_clock().now().nanoseconds
        deadline = time.monotonic() + 60.0
        while (
            self.get_clock().now().nanoseconds - start_time < 2_500_000_000
            and time.monotonic() < deadline
        ):
            self.cmd_vel.publish(command)
            rclpy.spin_once(self, timeout_sec=0.05)

        def moved():
            position = self.odom.pose.pose.position
            return math.hypot(position.x - start_xy[0], position.y - start_xy[1]) > 0.08

        self.spin_until(moved, 10.0, 'base displacement after cmd_vel')
        stopped_at = self.get_clock().now().nanoseconds
        self.spin_until(
            lambda: (
                self.get_clock().now().nanoseconds > stopped_at + 1_000_000_000
                and abs(self.odom.twist.twist.linear.x) < 0.01
                and abs(self.odom.twist.twist.angular.z) < 0.01
            ),
            30.0,
            'base watchdog stop after command publication ends',
        )

    def execute_trajectory(self, controller, joints, delta=0.03, all_joints=False):
        available = [joint for joint in joints if joint in self.joints]
        if not available:
            raise VerificationError(f'none of {joints} are present in joint_states')
        client = ActionClient(self, FollowJointTrajectory, f'{controller}/follow_joint_trajectory')
        if not client.wait_for_server(timeout_sec=30.0):
            raise VerificationError(f'{controller} action is unavailable')
        goal = FollowJointTrajectory.Goal()
        goal.trajectory = JointTrajectory()
        goal.trajectory.joint_names = available
        point = JointTrajectoryPoint()
        point.positions = [
            self.joints[name] + (delta if index == 0 or all_joints else 0.0)
            for index, name in enumerate(available)
        ]
        point.time_from_start.sec = 2
        goal.trajectory.points = [point]
        self.get_logger().info(f'{controller}: command {dict(zip(available, point.positions))}')
        sent = client.send_goal_async(goal)
        rclpy.spin_until_future_complete(self, sent, timeout_sec=15.0)
        handle = sent.result()
        if handle is None or not handle.accepted:
            raise VerificationError(f'{controller} rejected trajectory')
        result = handle.get_result_async()
        rclpy.spin_until_future_complete(self, result, timeout_sec=60.0)
        if result.result() is None or result.result().result.error_code != 0:
            raise VerificationError(f'{controller} trajectory failed')
        checked = available if all_joints else available[:1]
        targets = dict(zip(available, point.positions))
        self.spin_until(
            lambda: all(
                abs(self.joints[name] - targets[name]) < abs(delta) * 0.25 for name in checked
            ),
            15.0,
            f'{controller} measured joint displacement',
        )

    def verify_joint_actions(self):
        self.execute_trajectory('head_controller', ['head_1_joint', 'head_2_joint'], 0.2)
        self.execute_trajectory('torso_controller', ['torso_lift_joint'], 0.1)
        if self.args.no_arm:
            return
        self.execute_trajectory(
            'arm_controller', [f'arm_{index}_joint' for index in range(1, 8)], 0.1
        )
        if self.args.end_effector == 'pal-gripper':
            self.execute_trajectory(
                'gripper_controller',
                ['gripper_left_finger_joint', 'gripper_right_finger_joint'],
                0.02,
                all_joints=True,
            )
        elif self.args.end_effector.startswith('robotiq'):
            self.execute_trajectory('gripper_controller', ['gripper_finger_joint'], 0.15)
            multiplier = -1 if self.args.end_effector.endswith('140') else 1
            self.spin_until(
                lambda: (
                    abs(
                        self.joints['gripper_right_outer_knuckle_joint']
                        - multiplier * self.joints['gripper_finger_joint']
                    )
                    < 0.02
                ),
                15.0,
                'Robotiq physical follower motion',
            )
        elif self.args.end_effector == 'pal-hey5':
            candidates = ['hand_thumb_joint', 'hand_index_joint', 'hand_mrl_joint']
            before = self.joints.get('hand_thumb_flex_1_joint', 0.0)
            self.execute_trajectory('hand_controller', candidates, 0.3, all_joints=True)
            self.spin_until(
                lambda: self.joints.get('hand_thumb_flex_1_joint', before) > before + 0.02,
                15.0,
                'Hey5 physical thumb movement',
            )

    def verify_motion_library(self):
        service = self.create_client(ListMotions, 'play_motion2/list_motions')
        if not service.wait_for_service(timeout_sec=30.0):
            raise VerificationError('public motion library service is unavailable')
        future = service.call_async(ListMotions.Request())
        rclpy.spin_until_future_complete(self, future, timeout_sec=10.0)
        if future.result() is None or not future.result().motion_keys:
            raise VerificationError('public motion library is empty')
        client = ActionClient(self, PlayMotion2Raw, 'play_motion2/raw')
        if not client.wait_for_server(timeout_sec=30.0):
            raise VerificationError('public raw-motion action is unavailable')
        goal = PlayMotion2Raw.Goal()
        goal.skip_planning = True
        goal.motion.key = 'jazzy_runtime_head_test'
        goal.motion.joints = ['head_1_joint', 'head_2_joint']
        target = self.joints['head_1_joint'] + 0.1
        goal.motion.positions = [target, self.joints['head_2_joint']]
        goal.motion.times_from_start = [2.0]
        sent = client.send_goal_async(goal)
        rclpy.spin_until_future_complete(self, sent, timeout_sec=15.0)
        handle = sent.result()
        if handle is None or not handle.accepted:
            raise VerificationError('public raw-motion action rejected a valid motion')
        result = handle.get_result_async()
        rclpy.spin_until_future_complete(self, result, timeout_sec=60.0)
        if result.result() is None or not result.result().result.success:
            raise VerificationError('public raw-motion execution failed')
        self.spin_until(
            lambda: abs(self.joints['head_1_joint'] - target) < 0.025,
            15.0,
            'raw-motion measured head displacement',
        )

    def verify_moveit(self):
        if self.args.no_arm:
            return
        client = ActionClient(self, MoveGroup, 'move_action')
        if not client.wait_for_server(timeout_sec=60.0):
            raise VerificationError('MoveIt move_action is unavailable')
        goal = MoveGroup.Goal()
        goal.request.group_name = 'arm'
        goal.request.start_state.is_diff = True
        goal.planning_options.planning_scene_diff.is_diff = True
        goal.planning_options.planning_scene_diff.robot_state.is_diff = True
        goal.request.workspace_parameters.header.frame_id = 'base_footprint'
        goal.request.workspace_parameters.min_corner.x = -2.0
        goal.request.workspace_parameters.min_corner.y = -2.0
        goal.request.workspace_parameters.min_corner.z = -1.0
        goal.request.workspace_parameters.max_corner.x = 2.0
        goal.request.workspace_parameters.max_corner.y = 2.0
        goal.request.workspace_parameters.max_corner.z = 3.0
        goal.request.allowed_planning_time = 10.0
        goal.request.max_velocity_scaling_factor = 0.2
        goal.request.max_acceleration_scaling_factor = 0.2
        constraints = Constraints()
        for index in range(1, 8):
            name = f'arm_{index}_joint'
            constraint = JointConstraint()
            constraint.joint_name = name
            constraint.position = self.joints[name] + (0.03 if index == 1 else 0.0)
            constraint.tolerance_above = 0.01
            constraint.tolerance_below = 0.01
            constraint.weight = 1.0
            constraints.joint_constraints.append(constraint)
        goal.request.goal_constraints = [constraints]
        goal.planning_options.plan_only = False
        sent = client.send_goal_async(goal)
        rclpy.spin_until_future_complete(self, sent, timeout_sec=20.0)
        handle = sent.result()
        if handle is None or not handle.accepted:
            raise VerificationError('MoveIt rejected the representative goal')
        result = handle.get_result_async()
        rclpy.spin_until_future_complete(self, result, timeout_sec=90.0)
        if (
            result.result() is None
            or result.result().result.error_code.val != MoveItErrorCodes.SUCCESS
        ):
            raise VerificationError('MoveIt could not plan and execute the representative goal')

    def verify_navigation(self, distance=0.75):
        state_client = self.create_client(GetState, 'bt_navigator/get_state')
        if not state_client.wait_for_service(timeout_sec=60.0):
            raise VerificationError('Nav2 lifecycle service is unavailable')
        active = False
        deadline = time.monotonic() + 90.0
        while time.monotonic() < deadline:
            state = state_client.call_async(GetState.Request())
            rclpy.spin_until_future_complete(self, state, timeout_sec=5.0)
            if state.result() is not None and state.result().current_state.id == 3:
                active = True
                break
            rclpy.spin_once(self, timeout_sec=0.2)
        if not active:
            raise VerificationError('Nav2 navigator did not reach the active lifecycle state')
        client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        if not client.wait_for_server(timeout_sec=90.0):
            raise VerificationError('Nav2 navigate_to_pose action is unavailable')
        goal = NavigateToPose.Goal()
        goal.pose.header.frame_id = 'map'
        goal.pose.header.stamp = self.get_clock().now().to_msg()

        def localized():
            return self.tf_buffer.can_transform('map', 'base_footprint', rclpy.time.Time())

        self.spin_until(localized, 30.0, 'localized map/base TF')
        transform = self.tf_buffer.lookup_transform('map', 'base_footprint', rclpy.time.Time())
        goal.pose.pose.position.x = transform.transform.translation.x + distance
        goal.pose.pose.position.y = transform.transform.translation.y
        goal.pose.pose.orientation.w = 1.0
        sent = client.send_goal_async(goal)
        rclpy.spin_until_future_complete(self, sent, timeout_sec=20.0)
        handle = sent.result()
        if handle is None or not handle.accepted:
            raise VerificationError('Nav2 rejected the representative goal')
        result = handle.get_result_async()
        rclpy.spin_until_future_complete(self, result, timeout_sec=150.0)
        if result.result() is None or result.result().status != 4:
            handle.cancel_goal_async()
            raise VerificationError('Nav2 did not complete the representative goal')

    def verify_obstacle_avoidance(self):
        start = self.odom.pose.pose.position
        box_x, box_y = start.x + 1.3, start.y
        model = (
            '<sdf version="1.9"><model name="acceptance_obstacle"><static>true</static>'
            f'<pose>{box_x} {box_y} 0.4 0 0 0</pose><link name="box">'
            '<collision name="collision"><geometry><box><size>0.4 0.4 0.8</size>'
            '</box></geometry></collision><visual name="visual"><geometry><box>'
            '<size>0.4 0.4 0.8</size></box></geometry></visual></link></model></sdf>'
        )
        result = subprocess.run(
            [
                'gz',
                'service',
                '-s',
                '/world/navigation_acceptance/create',
                '--reqtype',
                'gz.msgs.EntityFactory',
                '--reptype',
                'gz.msgs.Boolean',
                '--timeout',
                '5000',
                '--req',
                'sdf: ' + json.dumps(model),
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode or 'data: true' not in result.stdout:
            raise VerificationError(
                'Harmonic could not create the test obstacle: ' + result.stdout
            )

        def lidar_detects_obstacle():
            scan = self.messages['scan_raw']
            return any(
                math.isfinite(distance) and 0.2 < distance < 1.4
                for index, distance in enumerate(scan.ranges)
                if abs(scan.angle_min + index * scan.angle_increment) < 0.15
            )

        self.spin_until(lidar_detects_obstacle, 20, 'lidar detection of the spawned obstacle')
        self.obstacle_track = []
        self.verify_navigation(distance=2.3)
        track = self.obstacle_track
        self.obstacle_track = None
        clearance = min(
            math.hypot(max(abs(x - box_x) - 0.2, 0), max(abs(y - box_y) - 0.2, 0))
            for x, y in track
        )
        detour = max(abs(y - box_y) for _, y in track)
        if clearance < 0.275 or detour < 0.4:
            raise VerificationError(
                f'Obstacle avoidance failed: clearance={clearance:.3f}, detour={detour:.3f}'
            )
        self.get_logger().info(
            f'Physical obstacle avoided: clearance={clearance:.3f}m, detour={detour:.3f}m'
        )

    def verify_slam(self):
        self.spin_until(
            lambda: self.map is not None and self.map.info.width > 0, 90.0, 'non-empty SLAM map'
        )


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--namespace', default='')
    parser.add_argument('--no-arm', action='store_true')
    parser.add_argument(
        '--end-effector',
        default='pal-gripper',
        choices=['pal-gripper', 'pal-hey5', 'robotiq-2f-85', 'robotiq-2f-140', 'no-end-effector'],
    )
    parser.add_argument('--no-ft-sensor', dest='ft_sensor', action='store_false')
    parser.add_argument('--no-camera', dest='camera', action='store_false')
    parser.add_argument('--no-laser', dest='laser', action='store_false')
    parser.add_argument('--base', choices=['pmb2', 'omni_base'], default='pmb2')
    parser.add_argument('--moveit', action='store_true')
    parser.add_argument('--navigation', action='store_true')
    parser.add_argument('--slam', action='store_true')
    parser.add_argument('--skip-motion', action='store_true')
    parser.add_argument('--gripper-only', action='store_true')
    parser.add_argument('--obstacle-check', action='store_true')
    return parser.parse_args()


def main():
    args = parse_args()
    rclpy.init(
        args=[
            '--ros-args',
            '-r',
            f'__ns:=/{args.namespace.strip("/")}',
            '-r',
            '/tf:=tf',
            '-r',
            '/tf_static:=tf_static',
        ]
    )
    node = RuntimeVerifier(args)
    try:
        if args.gripper_only:
            node.verify_controllers()
            joints = ['gripper_left_finger_joint', 'gripper_right_finger_joint']
            node.spin_until(
                lambda: all(joint in node.joints for joint in joints),
                30.0,
                'standalone gripper joint states',
            )
            node.spin_until(
                lambda: node.get_clock().now().nanoseconds > 0, 15.0, 'standalone simulation clock'
            )
            node.execute_trajectory('gripper_controller', joints, 0.02, all_joints=True)
            node.execute_trajectory('gripper_controller', joints, -0.02, all_joints=True)
            print('TIAGO_JAZZY_VERIFY: PASS')
            return 0
        node.verify_topics()
        node.verify_tf()
        node.verify_controllers()
        if not args.skip_motion and not args.navigation:
            node.verify_base_motion()
            node.verify_joint_actions()
            node.verify_motion_library()
        if args.moveit:
            node.verify_moveit()
        if args.slam:
            node.verify_slam()
        if args.navigation:
            node.verify_navigation()
        if args.obstacle_check:
            node.verify_obstacle_avoidance()
        print('TIAGO_JAZZY_VERIFY: PASS')
        return 0
    except VerificationError as error:
        node.get_logger().error(str(error))
        print(f'TIAGO_JAZZY_VERIFY: FAIL: {error}', file=sys.stderr)
        return 1
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    raise SystemExit(main())
