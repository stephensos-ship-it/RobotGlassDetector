// Copyright 2026 TIAGo Jazzy port contributors
// Licensed under the Apache License, Version 2.0.

#include <algorithm>
#include <chrono>
#include <string>
#include <vector>

#include <gz/common/Console.hh>
#include <gz/plugin/Register.hh>
#include <gz/sim/Joint.hh>
#include <gz/sim/Model.hh>
#include <gz/sim/System.hh>
#include <gz/sim/components/JointForceCmd.hh>

namespace tiago_gz_plugins
{
// Force-driven followers retain contact response rather than requiring the
// optional mimic-constraint feature of a Gazebo physics backend. Reductions and
// gains match PAL's public underactuated-finger model configuration.
class UnderactuatedHand final : public gz::sim::System,
  public gz::sim::ISystemConfigure, public gz::sim::ISystemPreUpdate
{
  struct Follower
  {
    gz::sim::Joint driver;
    gz::sim::Joint joint;
    double reduction;
    double integral{0.0};
  };

public:
  void Configure(const gz::sim::Entity & entity,
    const std::shared_ptr<const sdf::Element> & sdf,
    gz::sim::EntityComponentManager & ecm, gz::sim::EventManager &) override
  {
    const auto model = gz::sim::Model(entity);
    const std::string prefix = sdf->Get<std::string>("prefix", "hand").first;
    const auto add = [&](const std::string & driver, const std::string & name,
        double reduction)
      {
        const auto driver_entity = model.JointByName(ecm, prefix + "_" + driver + "_joint");
        const auto follower_entity = model.JointByName(ecm, prefix + "_" + name + "_joint");
        if (driver_entity == gz::sim::kNullEntity || follower_entity == gz::sim::kNullEntity) {
          gzerr << "TIAGo hand joint missing: " << prefix << "_" << name << "_joint\n";
          return;
        }
        Follower follower{gz::sim::Joint(driver_entity), gz::sim::Joint(follower_entity), reduction};
        follower.driver.EnablePositionCheck(ecm);
        follower.joint.EnablePositionCheck(ecm);
        follower.joint.EnableVelocityCheck(ecm);
        followers_.push_back(follower);
      };
    add("thumb", "thumb_abd", 2.0);
    add("thumb", "thumb_flex_1", 2.5);
    add("thumb", "thumb_virtual_1", 3.0);
    add("thumb", "thumb_flex_2", 3.5);
    add("thumb", "thumb_virtual_2", 3.0);
    add("index", "index_abd", 5.0);
    for (const auto & finger : {std::string("index"), std::string("middle"),
        std::string("ring"), std::string("little")})
    {
      const std::string driver = finger == "index" ? "index" : "mrl";
      add(driver, finger + "_flex_1", 2.5);
      add(driver, finger + "_virtual_1", 3.0);
      add(driver, finger + "_flex_2", 3.5);
      add(driver, finger + "_virtual_2", 3.5);
      add(driver, finger + "_flex_3", 4.0);
    }
  }

  void PreUpdate(const gz::sim::UpdateInfo & info,
    gz::sim::EntityComponentManager & ecm) override
  {
    if (info.paused) {
      return;
    }
    const double dt = std::chrono::duration<double>(info.dt).count();
    if (dt <= 0.0) {
      return;
    }
    for (auto & follower : followers_) {
      const auto driver = follower.driver.Position(ecm);
      const auto position = follower.joint.Position(ecm);
      const auto velocity = follower.joint.Velocity(ecm);
      if (!driver || !position || !velocity || driver->empty() ||
        position->empty() || velocity->empty())
      {
        continue;
      }
      const double error = (*driver)[0] / follower.reduction - (*position)[0];
      follower.integral = std::clamp(follower.integral + error * dt, -10.0, 10.0);
      const double force = std::clamp(50.0 * error + 0.1 * follower.integral -
        0.1 * (*velocity)[0], -2.0, 2.0);
      follower.joint.SetForce(ecm, {force});
    }
  }

private:
  std::vector<Follower> followers_;
};
}  // namespace tiago_gz_plugins

GZ_ADD_PLUGIN(tiago_gz_plugins::UnderactuatedHand, gz::sim::System,
  tiago_gz_plugins::UnderactuatedHand::ISystemConfigure,
  tiago_gz_plugins::UnderactuatedHand::ISystemPreUpdate)
